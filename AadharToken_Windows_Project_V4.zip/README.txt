Aadhar Token Windows application.
Build: GitHub Actions -> Build AadharToken Windows EXE -> Run workflow.
The generated EXE uses the Windows printer system for USB/Bluetooth printers installed in Windows.
