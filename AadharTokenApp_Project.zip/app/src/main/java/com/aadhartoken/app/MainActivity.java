package com.aadhartoken.app;

import android.app.*;
import android.os.*;
import android.graphics.Typeface;
import android.content.*;
import android.view.*;
import android.widget.*;
import java.text.*;
import java.util.*;

public class MainActivity extends Activity {
 Spinner token,time,enrol,demo; EditText date,support; LinearLayout demoL,supportL;
 String[] demos={"Name Update","Address Update","Mobile Update","Gender Update","Date of Birth Update","Email Update"};
 public void onCreate(Bundle b){super.onCreate(b); setContentView(R.layout.activity_main);
  token=findViewById(R.id.tokenSpinner); time=findViewById(R.id.timeSpinner); enrol=findViewById(R.id.enrolmentSpinner);
  demo=findViewById(R.id.demoSpinner); date=findViewById(R.id.dateEdit); support=findViewById(R.id.supportEdit);
  demoL=findViewById(R.id.demoLayout); supportL=findViewById(R.id.supportLayout);
  ArrayList<String> ts=new ArrayList<>(); for(int i=1;i<=100;i++)ts.add(""+i);
  token.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,ts));
  ArrayList<String> times=new ArrayList<>(); for(int h=1;h<=12;h++)for(int m=0;m<60;m+=5)for(String ap:new String[]{"AM","PM"})times.add(String.format(Locale.US,"%02d:%02d %s",h,m,ap));
  time.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,times));
  enrol.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"New","Biometric","Demographic"}));
  demo.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,demos));
  date.setText(new SimpleDateFormat("dd/MM/yyyy",Locale.US).format(new Date()));
  enrol.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){public void onNothingSelected(AdapterView<?> p){} public void onItemSelected(AdapterView<?> p,View v,int pos,long id){boolean x=pos==2; demoL.setVisibility(x?View.VISIBLE:View.GONE); updateSupport();}});
  demo.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){public void onNothingSelected(AdapterView<?> p){} public void onItemSelected(AdapterView<?> p,View v,int pos,long id){updateSupport();}});
  findViewById(R.id.previewBtn).setOnClickListener(v->preview());
  findViewById(R.id.resetBtn).setOnClickListener(v->{token.setSelection(0); enrol.setSelection(0); date.setText(new SimpleDateFormat("dd/MM/yyyy",Locale.US).format(new Date())); support.setText("");});
 }
 void updateSupport(){boolean show=enrol.getSelectedItemPosition()==2 && (demo.getSelectedItemPosition()==0||demo.getSelectedItemPosition()==1||demo.getSelectedItemPosition()==4); supportL.setVisibility(show?View.VISIBLE:View.GONE);}
 void preview(){
  String type=enrol.getSelectedItem().toString(); String s="AADHAR TOKEN\n\nTOKEN NO: "+token.getSelectedItem()+"\nDATE: "+date.getText()+"\nTIME: "+time.getSelectedItem()+"\n\nENROLMENT TYPE: "+type;
  if(type.equals("Demographic")){s+="\n\nDEMOGRAPHIC TYPE: "+demo.getSelectedItem(); if(supportL.getVisibility()==View.VISIBLE)s+="\n\nSUPPORTING DOCUMENT:\n____________________________";}
  s+="\n\n--------------------\nPLEASE WAIT";
  new AlertDialog.Builder(this).setTitle("Print Preview").setMessage(s).setPositiveButton("OK",null).show();
 }
}
