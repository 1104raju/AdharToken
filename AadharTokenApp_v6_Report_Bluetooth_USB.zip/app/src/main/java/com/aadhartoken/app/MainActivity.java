package com.aadhartoken.app;

import android.Manifest;
import android.app.*;
import android.bluetooth.*;
import android.hardware.usb.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.*;
import android.view.*;
import android.widget.*;
import java.io.OutputStream;
import java.io.IOException;
import java.nio.charset.Charset;
import java.text.SimpleDateFormat;
import java.util.*;
import android.content.SharedPreferences;

public class MainActivity extends Activity {
    Spinner token, hour, minute, ampm, enrol, demo, printer;
    String generatedToken = null;
    ArrayList<String> dailyReport = new ArrayList<>();
    SharedPreferences reportPrefs;
    EditText date, support;
    LinearLayout demoL, supportL;
    ArrayList<BluetoothDevice> devices = new ArrayList<>();
    final UUID SPP_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    String[] demos={"Name Update","Address Update","Mobile Update","Gender Update","Date of Birth Update","Email Update"};

    @Override public void onCreate(Bundle b) {
        super.onCreate(b); setContentView(R.layout.activity_main);
        token=findViewById(R.id.tokenSpinner); hour=findViewById(R.id.hourSpinner); minute=findViewById(R.id.minuteSpinner); ampm=findViewById(R.id.ampmSpinner);
        enrol=findViewById(R.id.enrolmentSpinner); demo=findViewById(R.id.demoSpinner);
        printer=findViewById(R.id.printerSpinner); date=findViewById(R.id.dateEdit);
        support=findViewById(R.id.supportEdit); demoL=findViewById(R.id.demoLayout); supportL=findViewById(R.id.supportLayout);

        ArrayList<String> ts=new ArrayList<>(); for(int i=1;i<=100;i++) ts.add(String.valueOf(i));
        token.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,ts));

        ArrayList<String> hours=new ArrayList<>();
        for(int h=1;h<=12;h++) hours.add(String.valueOf(h));
        hour.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,hours));

        ArrayList<String> minutes=new ArrayList<>();
        for(int m=0;m<60;m+=5) minutes.add(String.format(Locale.US,"%02d",m));
        minute.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,minutes));

        ampm.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,
                new String[]{"AM","PM"}));

        enrol.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,
                new String[]{"New","Biometric","Demographic"}));
        demo.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,demos));

        date.setText(new SimpleDateFormat("dd/MM/yyyy",Locale.US).format(new Date()));
        date.setOnClickListener(v -> chooseDate());

        enrol.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){
            public void onNothingSelected(AdapterView<?> p){}
            public void onItemSelected(AdapterView<?> p,View v,int pos,long id){
                demoL.setVisibility(pos==2?View.VISIBLE:View.GONE); updateSupport();
            }});
        demo.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){
            public void onNothingSelected(AdapterView<?> p){}
            public void onItemSelected(AdapterView<?> p,View v,int pos,long id){updateSupport();}
        });

        findViewById(R.id.refreshPrinterBtn).setOnClickListener(v -> loadPrinters());
        findViewById(R.id.testPrintBtn).setOnClickListener(v -> testPrint());
        findViewById(R.id.usbPrintBtn).setOnClickListener(v -> usbPrint(false));
        findViewById(R.id.usbTestBtn).setOnClickListener(v -> usbPrint(true));
        findViewById(R.id.generateBtn).setOnClickListener(v -> generateToken());
        findViewById(R.id.previewBtn).setOnClickListener(v -> preview());
        findViewById(R.id.printBtn).setOnClickListener(v -> printToken());
        findViewById(R.id.reprintBtn).setOnClickListener(v -> printToken());
        findViewById(R.id.newTokenBtn).setOnClickListener(v -> newToken());
        findViewById(R.id.resetBtn).setOnClickListener(v -> resetForm());

        loadPrinters();
        reportPrefs = getSharedPreferences("token_report", MODE_PRIVATE);
        loadReport();
        findViewById(R.id.reportBtn).setOnClickListener(v -> showReport());
    }

    void chooseDate(){
        Calendar c=Calendar.getInstance();
        try { c.setTime(new SimpleDateFormat("dd/MM/yyyy",Locale.US).parse(date.getText().toString())); } catch(Exception ignored){}
        new DatePickerDialog(this,(view,y,m,d)->date.setText(String.format(Locale.US,"%02d/%02d/%04d",d,m+1,y)),
                c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH)).show();
    }

    void updateSupport(){
        boolean show=enrol.getSelectedItemPosition()==2 &&
                (demo.getSelectedItemPosition()==0 || demo.getSelectedItemPosition()==1 || demo.getSelectedItemPosition()==4);
        supportL.setVisibility(show?View.VISIBLE:View.GONE);
    }

    String tokenText(){
        String type=enrol.getSelectedItem().toString();
        StringBuilder s=new StringBuilder();
        s.append("AADHAR TOKEN\n");
        s.append("------------------------------\n");
        s.append("TOKEN NO: ").append(token.getSelectedItem()).append("\n");
        s.append("DATE: ").append(date.getText()).append("\n");
        s.append("TIME: ").append(String.format(Locale.US,"%02d:%s %s", Integer.parseInt(hour.getSelectedItem().toString()), minute.getSelectedItem(), ampm.getSelectedItem())).append("\n");
        s.append("ENROLMENT TYPE: ").append(type).append("\n");
        if(type.equals("Demographic")){
            s.append("DEMOGRAPHIC TYPE: ").append(demo.getSelectedItem()).append("\n");
            if(supportL.getVisibility()==View.VISIBLE)
                s.append("SUPPORTING DOCUMENT:\n").append(support.getText()).append("\n");
        }
        s.append("------------------------------\n");
        s.append("PLEASE WAIT\n\n");
        return s.toString();
    }

    void generateToken(){
        if(generatedToken != null){
            new AlertDialog.Builder(this).setTitle("Token Already Generated")
                    .setMessage("Use PRINT TOKEN or PRINT AGAIN. Press NEW TOKEN before generating another token.")
                    .setPositiveButton("OK",null).show();
            return;
        }
        generatedToken = tokenText();
        String entry = token.getSelectedItem().toString() + " | " +
                String.format(Locale.US, "%02d:%s %s",
                        Integer.parseInt(hour.getSelectedItem().toString()),
                        minute.getSelectedItem(), ampm.getSelectedItem());
        dailyReport.add(entry);
        saveReport();
        new AlertDialog.Builder(this).setTitle("Token Generated")
                .setMessage(generatedToken)
                .setPositiveButton("PRINT TOKEN", (d,w) -> printToken())
                .setNegativeButton("CLOSE", null).show();
    }

    void preview(){
        new AlertDialog.Builder(this).setTitle("58mm Print Preview")
                .setMessage(tokenText()).setPositiveButton("OK",null).show();
    }

    boolean hasBluetoothPermission(){
        return Build.VERSION.SDK_INT < 31 ||
                checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)==PackageManager.PERMISSION_GRANTED;
    }

    void requestBluetoothPermission(){
        if(Build.VERSION.SDK_INT>=31) requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT},90);
    }

    void loadPrinters(){
        if(!hasBluetoothPermission()){ requestBluetoothPermission(); return; }
        BluetoothAdapter a=BluetoothAdapter.getDefaultAdapter();
        if(a==null){ toast("This phone does not support Bluetooth"); return; }
        if(!a.isEnabled()){ startActivity(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)); return; }
        devices.clear();
        ArrayList<String> names=new ArrayList<>();
        for(BluetoothDevice d:a.getBondedDevices()){
            devices.add(d); names.add(d.getName()+"  ("+d.getAddress()+")");
        }
        if(names.isEmpty()) names.add("No paired printers found");
        printer.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,names));
        if(!devices.isEmpty()) toast("Select a paired 58mm printer");
    }

    void usbPrint(boolean test){
        UsbManager manager=(UsbManager)getSystemService(Context.USB_SERVICE);
        HashMap<String,UsbDevice> list=manager.getDeviceList();
        if(list.isEmpty()){toast("No USB printer detected. Connect it using USB OTG.");return;}
        UsbDevice chosen=null;
        for(UsbDevice d:list.values()){
            if(d.getInterfaceCount()>0){chosen=d;break;}
        }
        if(chosen==null){toast("No compatible USB device found");return;}
        if(!manager.hasPermission(chosen)){
            PendingIntent pi=PendingIntent.getBroadcast(this,1,
                    new Intent("com.aadhartoken.app.USB_PERMISSION"),
                    PendingIntent.FLAG_IMMUTABLE);
            IntentFilter f=new IntentFilter("com.aadhartoken.app.USB_PERMISSION");
            if(Build.VERSION.SDK_INT>=33) registerReceiver(usbReceiver,f,Context.RECEIVER_NOT_EXPORTED);
            else registerReceiver(usbReceiver,f);
            manager.requestPermission(chosen,pi);
            toast("Allow USB printer permission, then tap USB PRINT again");
            return;
        }
        sendUsb(manager,chosen,test?testText():generatedToken);
    }

    final BroadcastReceiver usbReceiver=new BroadcastReceiver(){
        public void onReceive(Context c,Intent i){
            if("com.aadhartoken.app.USB_PERMISSION".equals(i.getAction())){
                UsbDevice d=i.getParcelableExtra(UsbManager.EXTRA_DEVICE);
                if(d!=null && i.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED,false))
                    toast("USB printer permission granted. Tap USB PRINT again.");
            }
        }
    };

    void sendUsb(UsbManager manager,UsbDevice device,String text){
        if(text==null){toast("Generate the token first");return;}
        new Thread(()->{
            UsbInterface intf=null; UsbEndpoint ep=null; UsbDeviceConnection conn=null;
            try{
                for(int i=0;i<device.getInterfaceCount() && intf==null;i++){
                    UsbInterface x=device.getInterface(i);
                    for(int e=0;e<x.getEndpointCount();e++){
                        UsbEndpoint q=x.getEndpoint(e);
                        if(q.getType()==UsbConstants.USB_ENDPOINT_XFER_BULK &&
                           q.getDirection()==UsbConstants.USB_DIR_OUT){intf=x;ep=q;break;}
                    }
                }
                if(intf==null){runOnUiThread(()->toast("USB printer output endpoint not found"));return;}
                conn=manager.openDevice(device);
                if(conn==null || !conn.claimInterface(intf,true)){runOnUiThread(()->toast("Cannot open USB printer"));return;}
                byte[] init={0x1B,0x40};
                byte[] center={0x1B,0x61,0x01};
                byte[] left={0x1B,0x61,0x00};
                byte[] body=text.getBytes(Charset.forName("UTF-8"));
                conn.bulkTransfer(ep,init,init.length,3000);
                conn.bulkTransfer(ep,center,center.length,3000);
                byte[] heading="AADHAR TOKEN\n".getBytes(Charset.forName("UTF-8")); conn.bulkTransfer(ep,heading,heading.length,3000);
                conn.bulkTransfer(ep,left,left.length,3000);
                conn.bulkTransfer(ep,body,body.length,5000);
                byte[] feed={0x0A,0x0A,0x0A};
                conn.bulkTransfer(ep,feed,feed.length,3000);
                conn.releaseInterface(intf); conn.close();
                runOnUiThread(()->toast("USB print sent"));
            }catch(Exception e){
                try{if(conn!=null)conn.close();}catch(Exception ignored){}
                runOnUiThread(()->toast("USB print failed. Check OTG and ESC/POS compatibility."));
            }
        }).start();
    }

    void testPrint(){
        if(devices.isEmpty()){toast("Pair the 58mm Bluetooth printer first"); return;}
        sendEscPos(testText());
    }

    String testText(){
        return "AADHAR TOKEN\n------------------------------\n58mm THERMAL TEST\nBluetooth ESC/POS OK\n------------------------------\n\n";
    }

    void printToken(){
        if(generatedToken == null){
            toast("Generate the token first");
            return;
        }
        if(devices.isEmpty()){toast("Pair the 58mm Bluetooth printer first"); return;}
        sendEscPos(generatedToken);
    }

    void sendEscPos(String text){
        new Thread(() -> {
            BluetoothSocket socket=null;
            try{
                BluetoothDevice d=devices.get(printer.getSelectedItemPosition());
                if(Build.VERSION.SDK_INT>=31 && !hasBluetoothPermission()){runOnUiThread(this::requestBluetoothPermission);return;}
                socket=d.createRfcommSocketToServiceRecord(SPP_UUID);
                socket.connect();
                OutputStream out=socket.getOutputStream();
                out.write(new byte[]{0x1B,0x40}); // ESC @ initialize
                out.write(new byte[]{0x1B,0x61,0x01}); // center
                out.write("AADHAR TOKEN\n".getBytes(Charset.forName("UTF-8")));
                out.write(new byte[]{0x1B,0x61,0x00}); // left
                out.write(text.substring(text.indexOf("\n")+1).getBytes(Charset.forName("UTF-8")));
                out.write(new byte[]{0x0A,0x0A,0x0A});
                out.write(new byte[]{0x1D,0x56,0x00}); // full cut if supported
                out.flush(); out.close(); socket.close();
                runOnUiThread(()->toast("Token sent to printer"));
            }catch(Exception e){
                try{if(socket!=null)socket.close();}catch(Exception ignored){}
                runOnUiThread(()->toast("Print failed. Pair the printer and select it."));
            }
        }).start();
    }

    void newToken(){
        generatedToken = null;
        support.setText("");
        toast("Ready for a new token");
    }

    void loadReport(){
        dailyReport.clear();
        String all=reportPrefs.getString("entries","");
        if(!all.isEmpty()){
            String[] rows=all.split("\n");
            for(String row:rows) if(!row.trim().isEmpty()) dailyReport.add(row);
        }
    }

    void saveReport(){
        StringBuilder b=new StringBuilder();
        for(String row:dailyReport){
            if(b.length()>0) b.append("\n");
            b.append(row);
        }
        reportPrefs.edit().putString("entries",b.toString()).apply();
    }

    void showReport(){
        StringBuilder b=new StringBuilder();
        b.append("DATE: ").append(date.getText()).append("\n\n");
        b.append(String.format(Locale.US,"%-12s%s\n","TOKEN NO.","TIME"));
        b.append("------------------------------\n");
        for(String row:dailyReport){
            String[] p=row.split("\\|",2);
            if(p.length==2)
                b.append(String.format(Locale.US,"%-12s%s\n",p[0].trim(),p[1].trim()));
        }
        b.append("------------------------------\n");
        b.append("TOTAL TOKENS: ").append(dailyReport.size());

        new AlertDialog.Builder(this)
                .setTitle("Daily Report")
                .setMessage(b.toString())
                .setPositiveButton("OK",null)
                .show();
    }

    void resetForm(){
        generatedToken = null;
        token.setSelection(0); hour.setSelection(0); minute.setSelection(0); ampm.setSelection(0); enrol.setSelection(0); support.setText("");
        date.setText(new SimpleDateFormat("dd/MM/yyyy",Locale.US).format(new Date()));
        loadPrinters();
    }

    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
}
