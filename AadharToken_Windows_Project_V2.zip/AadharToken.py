import tkinter as tk
from tkinter import ttk, messagebox
from datetime import datetime
import json, os, tempfile

APP_DIR=os.path.join(os.getenv("APPDATA") or os.getcwd(),"AadharToken")
os.makedirs(APP_DIR,exist_ok=True)
REPORT_FILE=os.path.join(APP_DIR,"daily_report.json")
def load_report():
    try:
        with open(REPORT_FILE,"r",encoding="utf-8") as f: return json.load(f)
    except: return {}
def save_report(data):
    with open(REPORT_FILE,"w",encoding="utf-8") as f: json.dump(data,f,indent=2)
report=load_report(); generated=None
root=tk.Tk(); root.title("Aadhar Token"); root.geometry("560x720"); root.minsize(500,650)
style=ttk.Style()
try: style.theme_use("clam")
except: pass
frm=ttk.Frame(root,padding=18); frm.pack(fill="both",expand=True)
ttk.Label(frm,text="AADHAR TOKEN",font=("Arial",20,"bold")).pack(pady=(0,18))
def row(label,widget):
    r=ttk.Frame(frm); r.pack(fill="x",pady=6)
    ttk.Label(r,text=label,width=20,font=("Arial",11,"bold")).pack(side="left")
    widget.pack(side="left",fill="x",expand=True); return r
token=ttk.Combobox(frm,values=[str(i) for i in range(1,101)],state="readonly"); token.set("1"); row("Token Number",token)
date_var=tk.StringVar(value=datetime.now().strftime("%d/%m/%Y")); row("Date",ttk.Entry(frm,textvariable=date_var))
tb=ttk.Frame(frm); tb.pack(fill="x",pady=6); ttk.Label(tb,text="Time",width=20,font=("Arial",11,"bold")).pack(side="left")
hour=ttk.Combobox(tb,values=[str(i) for i in range(1,13)],state="readonly"); hour.set(str(datetime.now().hour%12 or 12))
minute=ttk.Combobox(tb,values=[f"{i:02d}" for i in range(0,60,5)],state="readonly"); minute.set(f"{(datetime.now().minute//5)*5%60:02d}")
ampm=ttk.Combobox(tb,values=["AM","PM"],state="readonly"); ampm.set("AM" if datetime.now().hour<12 else "PM")
for x in (hour,minute,ampm): x.pack(side="left",fill="x",expand=True,padx=3)
enrol=ttk.Combobox(frm,values=["New","Biometric","Demographic"],state="readonly"); enrol.set("New"); row("Enrolment Type",enrol)
demo=ttk.Combobox(frm,values=["Name Update","Address Update","Mobile Update","Gender Update","Date of Birth Update","Email Update"],state="readonly")
demo.set("Name Update")
support_var=tk.StringVar()
support=ttk.Entry(frm,textvariable=support_var)

demo_row_frame=ttk.Frame(frm)
support_row_frame=ttk.Frame(frm)

ttk.Label(demo_row_frame,text="Demographic Type",width=20,font=("Arial",11,"bold")).pack(side="left")
demo.pack(in_=demo_row_frame,side="left",fill="x",expand=True)

ttk.Label(support_row_frame,text="Supporting Document",width=20,font=("Arial",11,"bold")).pack(side="left")
support.pack(in_=support_row_frame,side="left",fill="x",expand=True)

def update_demo(*_):
    # New and Biometric: hide all demographic controls.
    # Demographic: show Demographic Type.
    # Supporting Document: only Name, Address and Date of Birth.
    if enrol.get() == "Demographic":
        if not demo_row_frame.winfo_ismapped():
            demo_row_frame.pack(fill="x",pady=6)
        if demo.get() in ("Name Update","Address Update","Date of Birth Update"):
            if not support_row_frame.winfo_ismapped():
                support_row_frame.pack(fill="x",pady=6)
        else:
            if support_row_frame.winfo_ismapped():
                support_row_frame.pack_forget()
            support_var.set("")
    else:
        if demo_row_frame.winfo_ismapped():
            demo_row_frame.pack_forget()
        if support_row_frame.winfo_ismapped():
            support_row_frame.pack_forget()
        support_var.set("")

enrol.bind("<<ComboboxSelected>>",update_demo)
demo.bind("<<ComboboxSelected>>",update_demo)
update_demo()

def token_text():
    a=["AADHAR TOKEN","--------------------------------",f"TOKEN NO: {token.get()}",f"DATE: {date_var.get()}",f"TIME: {int(hour.get()):02d}:{minute.get()} {ampm.get()}",f"ENROLMENT TYPE: {enrol.get()}"]
    if enrol.get()=="Demographic":
        a.append(f"DEMOGRAPHIC TYPE: {demo.get()}")
        if demo.get() in ("Name Update","Address Update","Date of Birth Update"): a+=["SUPPORTING DOCUMENT:",support_var.get() or "____________________________"]
    return "\n".join(a+["--------------------------------","PLEASE WAIT"])
def generate():
    global generated
    if generated: return messagebox.showinfo("Token Already Generated","Use PRINT TOKEN or NEW TOKEN.")
    generated=token_text(); day=date_var.get()
    report.setdefault(day,[]).append({"token":token.get(),"time":f"{int(hour.get()):02d}:{minute.get()} {ampm.get()}"}); save_report(report); preview()
def preview():
    w=tk.Toplevel(root); w.title("58mm Print Preview"); t=tk.Text(w,width=40,height=22,font=("Courier New",10)); t.pack(padx=12,pady=12); t.insert("1.0",generated); t.config(state="disabled"); ttk.Button(w,text="PRINT TOKEN",command=lambda:(print_text(generated),w.destroy())).pack(pady=10)
def print_text(text):
    fd,path=tempfile.mkstemp(suffix=".txt"); os.close(fd)
    with open(path,"w",encoding="utf-8") as f:f.write(text)
    try: os.startfile(path,"print")
    except Exception as e: messagebox.showerror("Printing","Set your thermal printer as a Windows printer first.\n\n"+str(e))
def print_current():
    if generated: print_text(generated)
    else: messagebox.showwarning("Generate Token","Generate the token first.")
def new_token():
    global generated
    generated=None; support_var.set("")
def show_report():
    day=date_var.get(); rows=report.get(day,[]); w=tk.Toplevel(root); w.title("Daily Report")
    ttk.Label(w,text=f"DAILY REPORT - {day}",font=("Arial",14,"bold")).pack(pady=10)
    tree=ttk.Treeview(w,columns=("token","time"),show="headings",height=18); tree.heading("token",text="Token No."); tree.heading("time",text="Time"); tree.pack(padx=12,pady=8,fill="both",expand=True)
    for r in rows: tree.insert("", "end",values=(r["token"],r["time"]))
    ttk.Label(w,text=f"Total Tokens: {len(rows)}",font=("Arial",11,"bold")).pack(pady=6)
    ttk.Button(w,text="PRINT REPORT",command=lambda:print_report(day,rows)).pack(pady=10)
def print_report(day,rows):
    s=f"AADHAR TOKEN\nDAILY REPORT\nDATE: {day}\n--------------------------------\nTOKEN NO.    TIME\n"
    s+="".join(f"{r['token']:<12}{r['time']}\n" for r in rows)+f"--------------------------------\nTOTAL TOKENS: {len(rows)}\n"; print_text(s)
bf=ttk.Frame(frm); bf.pack(fill="x",pady=18)
for i,(label,cmd) in enumerate([("GENERATE TOKEN",generate),("PRINT TOKEN",print_current),("PRINT AGAIN",print_current),("NEW TOKEN",new_token),("DAILY REPORT",show_report)]):
    ttk.Button(bf,text=label,command=cmd).grid(row=i//2,column=i%2,padx=5,pady=5,sticky="ew")
bf.columnconfigure(0,weight=1); bf.columnconfigure(1,weight=1)
ttk.Label(frm,text="58mm thermal layout • Windows printer support").pack(side="bottom",pady=6)
root.mainloop()
